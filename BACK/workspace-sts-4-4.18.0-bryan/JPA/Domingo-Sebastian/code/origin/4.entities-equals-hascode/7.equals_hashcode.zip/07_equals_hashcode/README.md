## Proyecto para añadir implementación equals/hashcode

Proyecto que sirve de base para investigar problemas relacionados con la implementacion de equals y hashcode.