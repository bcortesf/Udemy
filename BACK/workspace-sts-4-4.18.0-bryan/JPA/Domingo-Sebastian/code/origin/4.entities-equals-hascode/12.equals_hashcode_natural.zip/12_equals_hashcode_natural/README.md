## Uso de una propiedad natural para equals y hashcode

Uso de la propiedad natural para evitar los errors mostrados en la lección anterior