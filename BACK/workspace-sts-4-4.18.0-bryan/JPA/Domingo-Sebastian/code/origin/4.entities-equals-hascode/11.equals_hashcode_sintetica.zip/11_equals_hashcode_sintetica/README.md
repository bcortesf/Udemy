## Uso de una propiedad sintetica para equals y hashcode

Proyecto que muestra problemas que podemos tener si usamos una clave sintetica para implementar equals y hashcode