## Proyecto main mínimo con JPA usando EclipseLink.

Respecto al anterior proyecto hay los siguientes cambios:

- en el fichero pom.xml se ha sustituido la dependencia a Hibernate por una a EclipseLink
- en persistence.xml se ha añadido una propiedad para mostrar los logs de EclipseLink

Como primer paso intentad ejecutar el código tal como se muestra.

¿Te da error? :fearful: ¿Sabrías solucionar el problema?

Tienes la solución en el fichero [solucion.txt](solucion.txt)
