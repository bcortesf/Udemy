package com.sys.elite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysPlantillaApplicationTests {

	@Test
	void contextLoads() {
	}

}
