package com.company.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootThymeleafMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
