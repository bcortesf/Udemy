package com.bcf.sqs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqsApplicationTests {

	@Test
	void contextLoads() {
	}

}
