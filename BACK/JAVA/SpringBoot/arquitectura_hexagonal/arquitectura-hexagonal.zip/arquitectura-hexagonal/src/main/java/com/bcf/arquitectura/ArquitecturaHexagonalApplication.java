package com.bcf.arquitectura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArquitecturaHexagonalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArquitecturaHexagonalApplication.class, args);
	}

}
