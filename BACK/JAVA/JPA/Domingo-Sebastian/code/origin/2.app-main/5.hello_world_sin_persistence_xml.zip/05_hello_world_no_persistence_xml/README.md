## Proyecto main sin usar persistence.xml

Proyecto simulando el comportamiento de un contenedor iniciando un 
persistence provider.