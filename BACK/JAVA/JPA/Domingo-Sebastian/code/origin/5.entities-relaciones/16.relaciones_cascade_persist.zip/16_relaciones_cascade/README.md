## Relaciones : cascade persist

¿Puede una operación de merge propagar una operación de persist?