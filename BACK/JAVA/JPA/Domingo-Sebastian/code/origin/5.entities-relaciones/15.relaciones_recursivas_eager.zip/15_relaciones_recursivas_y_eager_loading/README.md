## Relaciones recursivas

¿Como afecta una relación recursiva al eager loading?