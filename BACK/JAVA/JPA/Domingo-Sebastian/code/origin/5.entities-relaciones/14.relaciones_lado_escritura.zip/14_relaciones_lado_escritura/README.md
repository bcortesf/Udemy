## Relaciones bidireccionales, propiedad de escritura

Proyecto para analizar que lado de una relación bidireccional se usa para actualitzar la columna con la foreign key en la base de datos