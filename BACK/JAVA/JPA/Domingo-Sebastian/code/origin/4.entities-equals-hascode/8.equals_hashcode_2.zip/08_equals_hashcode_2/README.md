## Proyecto para añadir implementación equals/hashcode (2)

Proyecto que presenta los problemas de una implementación de equals y hashcode usando la comparación directa de los tipos.