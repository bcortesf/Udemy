## Uso de una propiedad natural para equals y hashcode - problemas

Aunque el uso de una propiedad natural para implementar equals y hashcode nos resuelve algunos problemas, tampoco está exento de los suyos !