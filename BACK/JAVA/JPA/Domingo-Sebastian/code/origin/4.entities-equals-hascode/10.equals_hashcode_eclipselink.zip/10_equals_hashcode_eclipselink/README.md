## Proyecto que muestra implementación equals/hashcode con eclipselink

Proyecto que muestra como las diferencias de implementación de eclipselink y hibernate pueden tener efectos en los requisitos para implementar equals y hashcode.