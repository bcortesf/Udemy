## Proyecto para añadir implementación equals/hashcode (ok)

Proyecto con la implementación correcta de equals y hashcode