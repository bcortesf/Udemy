## Ejemplo de inicialización del proxy

Proyecto usado para observar en que momento se inicializa un objeto recuperado
mediante un getReference (lazy loading) y de que tipo es.